import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import { useAuth } from "@/hooks/useAuth";
import { ClientLayout } from "@/components/ClientLayout";
import { AdminLayout } from "@/components/AdminLayout";

import NotFound from "@/pages/not-found";
import Landing from "@/pages/Landing";
import Home from "@/pages/Home";
import Services from "@/pages/Services";
import Products from "@/pages/Products";
import Booking from "@/pages/Booking";
import Queue from "@/pages/Queue";
import Chat from "@/pages/Chat";
import Appointments from "@/pages/Appointments";
import Promotions from "@/pages/Promotions";
import Notifications from "@/pages/Notifications";
import Profile from "@/pages/Profile";

import AdminDashboard from "@/pages/admin/Dashboard";
import AdminServices from "@/pages/admin/Services";
import AdminSettings from "@/pages/admin/Settings";

function ClientRoutes() {
  return (
    <ClientLayout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/services" component={Services} />
        <Route path="/products" component={Products} />
        <Route path="/booking" component={Booking} />
        <Route path="/queue" component={Queue} />
        <Route path="/chat" component={Chat} />
        <Route path="/appointments" component={Appointments} />
        <Route path="/promotions" component={Promotions} />
        <Route path="/notifications" component={Notifications} />
        <Route path="/profile" component={Profile} />
        <Route component={NotFound} />
      </Switch>
    </ClientLayout>
  );
}

function AdminRoutes() {
  return (
    <AdminLayout>
      <Switch>
        <Route path="/admin" component={AdminDashboard} />
        <Route path="/admin/services" component={AdminServices} />
        <Route path="/admin/products" component={AdminServices} />
        <Route path="/admin/promotions" component={AdminServices} />
        <Route path="/admin/appointments" component={AdminDashboard} />
        <Route path="/admin/queue" component={AdminDashboard} />
        <Route path="/admin/chat" component={Chat} />
        <Route path="/admin/clients" component={AdminDashboard} />
        <Route path="/admin/staff" component={AdminDashboard} />
        <Route path="/admin/settings" component={AdminSettings} />
        <Route path="/admin/notifications" component={Notifications} />
        <Route component={NotFound} />
      </Switch>
    </AdminLayout>
  );
}

function Router() {
  const { isAuthenticated, isLoading, user } = useAuth();
  const [location] = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4 animate-pulse">
            <div className="w-6 h-6 rounded-full bg-primary animate-ping" />
          </div>
          <p className="text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Landing />;
  }

  if (location.startsWith("/admin")) {
    const isAdmin = user?.role === "admin" || user?.role === "staff";
    if (!isAdmin) {
      return <ClientRoutes />;
    }
    return <AdminRoutes />;
  }

  return <ClientRoutes />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <Router />
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
