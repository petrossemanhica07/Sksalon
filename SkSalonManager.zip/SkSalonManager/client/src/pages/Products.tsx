import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ShoppingBag, Package, Sparkles, Tag } from "lucide-react";
import type { Product, ProductCategory } from "@shared/schema";

export default function Products() {
  const { data: categories, isLoading: loadingCategories } = useQuery<ProductCategory[]>({
    queryKey: ["/api/product-categories"],
  });

  const { data: products, isLoading: loadingProducts } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const getProductsByCategory = (categoryId: number) => {
    return products?.filter(p => p.categoryId === categoryId && p.isActive) || [];
  };

  const allActiveProducts = products?.filter(p => p.isActive) || [];

  if (loadingCategories || loadingProducts) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-48" />
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
            <Skeleton key={i} className="h-72" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold" data-testid="text-page-title">Produtos</h1>
        <p className="text-muted-foreground">Produtos profissionais para seu cabelo</p>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="w-full flex flex-wrap h-auto gap-2 bg-transparent p-0 justify-start">
          <TabsTrigger value="all" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            Todos
          </TabsTrigger>
          {categories?.map(category => (
            <TabsTrigger 
              key={category.id} 
              value={category.id.toString()}
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              {category.name}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {allActiveProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          {allActiveProducts.length === 0 && <EmptyState />}
        </TabsContent>

        {categories?.map(category => (
          <TabsContent key={category.id} value={category.id.toString()} className="mt-6">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {getProductsByCategory(category.id).map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
            {getProductsByCategory(category.id).length === 0 && <EmptyState />}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}

function ProductCard({ product }: { product: Product }) {
  const formatPrice = (price: string) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL"
    }).format(parseFloat(price));
  };

  const hasDiscount = product.originalPrice && parseFloat(product.originalPrice) > parseFloat(product.price);

  return (
    <Card className="overflow-hidden hover-elevate" data-testid={`card-product-${product.id}`}>
      <div className="aspect-square bg-gradient-to-br from-accent/30 to-primary/10 flex items-center justify-center relative">
        {product.imageUrl ? (
          <img 
            src={product.imageUrl} 
            alt={product.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <Package className="w-16 h-16 text-primary/30" />
        )}
        {hasDiscount && (
          <Badge className="absolute top-2 right-2 bg-destructive">
            <Tag className="w-3 h-3 mr-1" />
            Oferta
          </Badge>
        )}
        {product.stock !== null && product.stock <= 5 && product.stock > 0 && (
          <Badge variant="secondary" className="absolute bottom-2 left-2">
            Últimas {product.stock} unidades
          </Badge>
        )}
        {product.stock === 0 && (
          <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
            <Badge variant="outline">Esgotado</Badge>
          </div>
        )}
      </div>
      <CardContent className="p-4">
        <h3 className="font-medium text-sm line-clamp-2 mb-2" data-testid={`text-product-name-${product.id}`}>
          {product.name}
        </h3>
        <div className="flex items-end gap-2 flex-wrap">
          <span className="text-lg font-bold text-primary" data-testid={`text-product-price-${product.id}`}>
            {formatPrice(product.price)}
          </span>
          {hasDiscount && (
            <span className="text-sm text-muted-foreground line-through">
              {formatPrice(product.originalPrice!)}
            </span>
          )}
        </div>
        <Button 
          className="w-full mt-3" 
          size="sm"
          disabled={product.stock === 0}
        >
          <ShoppingBag className="w-4 h-4 mr-2" />
          {product.stock === 0 ? "Indisponível" : "Reservar"}
        </Button>
      </CardContent>
    </Card>
  );
}

function EmptyState() {
  return (
    <div className="text-center py-16">
      <ShoppingBag className="w-16 h-16 mx-auto text-muted-foreground/30 mb-4" />
      <h3 className="text-lg font-medium mb-2">Nenhum produto encontrado</h3>
      <p className="text-muted-foreground">
        Novos produtos em breve!
      </p>
    </div>
  );
}
