import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import { Clock, Scissors, Sparkles, ArrowRight } from "lucide-react";
import type { Service, ServiceCategory } from "@shared/schema";

export default function Services() {
  const { data: categories, isLoading: loadingCategories } = useQuery<ServiceCategory[]>({
    queryKey: ["/api/service-categories"],
  });

  const { data: services, isLoading: loadingServices } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  const getServicesByCategory = (categoryId: number) => {
    return services?.filter(s => s.categoryId === categoryId && s.isActive) || [];
  };

  const allActiveServices = services?.filter(s => s.isActive) || [];

  if (loadingCategories || loadingServices) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between gap-4">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <Skeleton key={i} className="h-64" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-page-title">Nossos Serviços</h1>
          <p className="text-muted-foreground">Escolha o serviço ideal para você</p>
        </div>
        <Button asChild>
          <Link href="/booking" data-testid="button-book-now">
            Agendar Agora
            <ArrowRight className="w-4 h-4 ml-2" />
          </Link>
        </Button>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="w-full flex flex-wrap h-auto gap-2 bg-transparent p-0 justify-start">
          <TabsTrigger value="all" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            Todos
          </TabsTrigger>
          {categories?.map(category => (
            <TabsTrigger 
              key={category.id} 
              value={category.id.toString()}
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              {category.name}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {allActiveServices.map(service => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>
          {allActiveServices.length === 0 && (
            <EmptyState />
          )}
        </TabsContent>

        {categories?.map(category => (
          <TabsContent key={category.id} value={category.id.toString()} className="mt-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {getServicesByCategory(category.id).map(service => (
                <ServiceCard key={service.id} service={service} />
              ))}
            </div>
            {getServicesByCategory(category.id).length === 0 && (
              <EmptyState />
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}

function ServiceCard({ service }: { service: Service }) {
  const formatPrice = (price: string) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL"
    }).format(parseFloat(price));
  };

  const formatDuration = (minutes: number) => {
    if (minutes < 60) return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return mins > 0 ? `${hours}h${mins}` : `${hours}h`;
  };

  return (
    <Card className="overflow-hidden hover-elevate group" data-testid={`card-service-${service.id}`}>
      <div className="h-48 bg-gradient-to-br from-primary/20 via-accent/10 to-primary/5 flex items-center justify-center relative overflow-hidden">
        {service.imageUrl ? (
          <img 
            src={service.imageUrl} 
            alt={service.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="text-center">
            <Scissors className="w-16 h-16 text-primary/40 mx-auto mb-2" />
            <Sparkles className="w-6 h-6 text-primary/30 absolute top-4 right-4" />
          </div>
        )}
        <div className="absolute top-4 left-4">
          <Badge variant="secondary" className="bg-background/90 backdrop-blur-sm">
            <Clock className="w-3 h-3 mr-1" />
            {formatDuration(service.duration)}
          </Badge>
        </div>
      </div>
      <CardContent className="p-5">
        <h3 className="font-semibold text-lg mb-2" data-testid={`text-service-name-${service.id}`}>{service.name}</h3>
        {service.description && (
          <p className="text-muted-foreground text-sm mb-4 line-clamp-2">{service.description}</p>
        )}
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <span className="text-2xl font-bold text-primary" data-testid={`text-service-price-${service.id}`}>
            {formatPrice(service.price)}
          </span>
          <Button asChild size="sm">
            <Link href={`/booking?service=${service.id}`}>
              Agendar
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function EmptyState() {
  return (
    <div className="text-center py-16">
      <Scissors className="w-16 h-16 mx-auto text-muted-foreground/30 mb-4" />
      <h3 className="text-lg font-medium mb-2">Nenhum serviço encontrado</h3>
      <p className="text-muted-foreground">
        Estamos preparando novos serviços para você.
      </p>
    </div>
  );
}
