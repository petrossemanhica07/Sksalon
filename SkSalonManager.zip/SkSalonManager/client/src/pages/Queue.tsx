import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Users, 
  Clock, 
  UserCheck, 
  Bell,
  RefreshCw,
  Plus,
  AlertCircle
} from "lucide-react";
import type { Queue as QueueType, Service } from "@shared/schema";
import { motion, AnimatePresence } from "framer-motion";

export default function Queue() {
  const { toast } = useToast();
  const [selectedService, setSelectedService] = useState<string>("");

  const { data: myPosition, isLoading: loadingPosition, refetch: refetchPosition } = useQuery<QueueType | null>({
    queryKey: ["/api/queue/my-position"],
    refetchInterval: 10000,
  });

  const { data: queueList, isLoading: loadingQueue, refetch: refetchQueue } = useQuery<QueueType[]>({
    queryKey: ["/api/queue"],
    refetchInterval: 10000,
  });

  const { data: services } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  const joinQueue = useMutation({
    mutationFn: async (serviceId: number) => {
      await apiRequest("POST", "/api/queue/join", { serviceId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/queue"] });
      toast({
        title: "Você entrou na fila!",
        description: "Acompanhe sua posição aqui.",
      });
    },
    onError: () => {
      toast({
        title: "Erro ao entrar na fila",
        description: "Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const leaveQueue = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/queue/leave", {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/queue"] });
      toast({
        title: "Você saiu da fila",
        description: "Até a próxima!",
      });
    },
    onError: () => {
      toast({
        title: "Erro ao sair da fila",
        variant: "destructive",
      });
    },
  });

  const handleJoinQueue = () => {
    if (!selectedService) {
      toast({
        title: "Selecione um serviço",
        description: "Escolha o serviço desejado para entrar na fila.",
        variant: "destructive",
      });
      return;
    }
    joinQueue.mutate(parseInt(selectedService));
  };

  const handleRefresh = () => {
    refetchPosition();
    refetchQueue();
  };

  const waitingCount = queueList?.filter(q => q.status === "waiting").length || 0;
  const inServiceCount = queueList?.filter(q => q.status === "in_service").length || 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-page-title">Fila de Atendimento</h1>
          <p className="text-muted-foreground">Acompanhe em tempo real</p>
        </div>
        <Button variant="outline" onClick={handleRefresh} data-testid="button-refresh">
          <RefreshCw className="w-4 h-4 mr-2" />
          Atualizar
        </Button>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-10 h-10 rounded-full bg-chart-4/10 flex items-center justify-center mx-auto mb-2">
              <Users className="w-5 h-5 text-chart-4" />
            </div>
            <p className="text-2xl font-bold" data-testid="text-waiting-count">{waitingCount}</p>
            <p className="text-sm text-muted-foreground">Aguardando</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-10 h-10 rounded-full bg-chart-5/10 flex items-center justify-center mx-auto mb-2">
              <UserCheck className="w-5 h-5 text-chart-5" />
            </div>
            <p className="text-2xl font-bold" data-testid="text-service-count">{inServiceCount}</p>
            <p className="text-sm text-muted-foreground">Em atendimento</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-2">
              <Clock className="w-5 h-5 text-primary" />
            </div>
            <p className="text-2xl font-bold" data-testid="text-avg-wait">~15</p>
            <p className="text-sm text-muted-foreground">Min/cliente</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-10 h-10 rounded-full bg-chart-3/10 flex items-center justify-center mx-auto mb-2">
              <Bell className="w-5 h-5 text-chart-3" />
            </div>
            <p className="text-2xl font-bold">Ativo</p>
            <p className="text-sm text-muted-foreground">Alertas</p>
          </CardContent>
        </Card>
      </div>

      {/* My Position */}
      {loadingPosition ? (
        <Skeleton className="h-40" />
      ) : myPosition ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          <Card className="border-primary/30 bg-gradient-to-br from-primary/5 to-accent/5">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-center gap-6">
                <div className="relative">
                  <div className="w-24 h-24 rounded-full bg-primary flex items-center justify-center">
                    <span className="text-4xl font-bold text-primary-foreground" data-testid="text-my-position">
                      #{myPosition.position}
                    </span>
                  </div>
                  <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-chart-5 flex items-center justify-center animate-pulse">
                    <Clock className="w-4 h-4 text-white" />
                  </div>
                </div>
                <div className="flex-1 text-center md:text-left">
                  <h2 className="text-xl font-bold mb-1">Sua posição na fila</h2>
                  <p className="text-muted-foreground mb-4">
                    Tempo estimado de espera: <span className="font-semibold text-foreground">{myPosition.estimatedWait || 15} minutos</span>
                  </p>
                  <div className="w-full max-w-md mx-auto md:mx-0">
                    <div className="flex items-center justify-between text-sm mb-2">
                      <span>Progresso</span>
                      <span>{100 - (myPosition.position * 20)}%</span>
                    </div>
                    <Progress value={100 - (myPosition.position * 20)} className="h-2" />
                  </div>
                </div>
                <Button 
                  variant="outline" 
                  onClick={() => leaveQueue.mutate()}
                  disabled={leaveQueue.isPending}
                  data-testid="button-leave-queue"
                >
                  Sair da Fila
                </Button>
              </div>

              {myPosition.position <= 2 && (
                <div className="mt-4 p-4 bg-chart-4/10 rounded-lg flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 text-chart-4" />
                  <p className="text-sm font-medium">
                    Prepare-se! Você será atendido em breve.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      ) : (
        <Card>
          <CardContent className="p-6">
            <div className="text-center mb-6">
              <Users className="w-16 h-16 mx-auto text-muted-foreground/30 mb-4" />
              <h2 className="text-xl font-semibold mb-2">Entre na Fila</h2>
              <p className="text-muted-foreground">
                Selecione o serviço desejado e aguarde sua vez
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <Select value={selectedService} onValueChange={setSelectedService}>
                <SelectTrigger data-testid="select-service">
                  <SelectValue placeholder="Selecione o serviço" />
                </SelectTrigger>
                <SelectContent>
                  {services?.filter(s => s.isActive).map(service => (
                    <SelectItem key={service.id} value={service.id.toString()}>
                      {service.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button 
                onClick={handleJoinQueue}
                disabled={joinQueue.isPending || !selectedService}
                data-testid="button-join-queue"
              >
                <Plus className="w-4 h-4 mr-2" />
                Entrar na Fila
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Queue List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Fila Atual
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loadingQueue ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => <Skeleton key={i} className="h-16" />)}
            </div>
          ) : queueList && queueList.length > 0 ? (
            <div className="space-y-3">
              <AnimatePresence>
                {queueList.filter(q => q.status !== "completed").map((item, index) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ delay: index * 0.05 }}
                    className={`flex items-center gap-4 p-4 rounded-lg ${
                      item.status === "in_service" 
                        ? "bg-chart-5/10 border border-chart-5/30" 
                        : item.status === "called"
                          ? "bg-chart-4/10 border border-chart-4/30"
                          : "bg-muted/50"
                    }`}
                    data-testid={`queue-item-${item.id}`}
                  >
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                      item.status === "in_service" 
                        ? "bg-chart-5 text-white" 
                        : item.status === "called"
                          ? "bg-chart-4 text-white animate-pulse"
                          : "bg-primary/10 text-primary"
                    }`}>
                      #{item.position}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">Cliente #{item.clientId?.slice(-4) || "---"}</p>
                      <p className="text-sm text-muted-foreground">
                        Serviço #{item.serviceId}
                      </p>
                    </div>
                    <Badge variant={
                      item.status === "in_service" ? "default" :
                      item.status === "called" ? "secondary" :
                      "outline"
                    }>
                      {item.status === "in_service" ? "Atendendo" :
                       item.status === "called" ? "Chamado" :
                       item.status === "waiting" ? "Aguardando" :
                       item.status}
                    </Badge>
                    {item.estimatedWait && (
                      <span className="text-sm text-muted-foreground hidden sm:block">
                        ~{item.estimatedWait} min
                      </span>
                    )}
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              <Users className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>Nenhum cliente na fila</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
