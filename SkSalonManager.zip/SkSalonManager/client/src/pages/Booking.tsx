import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation, useSearch } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Scissors, 
  Calendar as CalendarIcon, 
  Clock, 
  User,
  ChevronRight,
  Check,
  ArrowLeft
} from "lucide-react";
import type { Service, User as UserType, StaffSchedule } from "@shared/schema";
import { format, addDays, setHours, setMinutes, isBefore, isAfter } from "date-fns";
import { ptBR } from "date-fns/locale";

type Step = "service" | "staff" | "datetime" | "confirm";

export default function Booking() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const searchString = useSearch();
  const params = new URLSearchParams(searchString);
  const preselectedServiceId = params.get("service");

  const [step, setStep] = useState<Step>("service");
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedStaff, setSelectedStaff] = useState<UserType | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [notes, setNotes] = useState("");

  const { data: services, isLoading: loadingServices } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  const { data: staff, isLoading: loadingStaff } = useQuery<UserType[]>({
    queryKey: ["/api/staff"],
  });

  const { data: schedules } = useQuery<StaffSchedule[]>({
    queryKey: ["/api/staff-schedules", selectedStaff?.id],
    enabled: !!selectedStaff,
  });

  const createAppointment = useMutation({
    mutationFn: async (data: any) => {
      await apiRequest("POST", "/api/appointments", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      toast({
        title: "Agendamento realizado!",
        description: "Você receberá uma confirmação em breve.",
      });
      navigate("/appointments");
    },
    onError: () => {
      toast({
        title: "Erro ao agendar",
        description: "Tente novamente mais tarde.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (preselectedServiceId && services) {
      const service = services.find(s => s.id === parseInt(preselectedServiceId));
      if (service) {
        setSelectedService(service);
        setStep("staff");
      }
    }
  }, [preselectedServiceId, services]);

  const formatPrice = (price: string) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL"
    }).format(parseFloat(price));
  };

  const formatDuration = (minutes: number) => {
    if (minutes < 60) return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return mins > 0 ? `${hours}h${mins}` : `${hours}h`;
  };

  const generateTimeSlots = () => {
    if (!selectedDate || !schedules) return [];
    
    const dayOfWeek = selectedDate.getDay();
    const schedule = schedules.find(s => s.dayOfWeek === dayOfWeek && s.isWorking);
    
    if (!schedule) return [];

    const slots: string[] = [];
    const [startHour, startMin] = schedule.startTime.split(":").map(Number);
    const [endHour, endMin] = schedule.endTime.split(":").map(Number);
    
    let current = setMinutes(setHours(selectedDate, startHour), startMin);
    const end = setMinutes(setHours(selectedDate, endHour), endMin);
    
    while (isBefore(current, end)) {
      slots.push(format(current, "HH:mm"));
      current = new Date(current.getTime() + 30 * 60 * 1000);
    }
    
    return slots;
  };

  const handleConfirm = () => {
    if (!selectedService || !selectedStaff || !selectedDate || !selectedTime) return;

    const [hours, minutes] = selectedTime.split(":").map(Number);
    const appointmentDate = setMinutes(setHours(selectedDate, hours), minutes);

    createAppointment.mutate({
      serviceId: selectedService.id,
      staffId: selectedStaff.id,
      date: appointmentDate.toISOString(),
      notes: notes || null,
    });
  };

  const goBack = () => {
    if (step === "staff") setStep("service");
    else if (step === "datetime") setStep("staff");
    else if (step === "confirm") setStep("datetime");
  };

  const steps = [
    { key: "service", label: "Serviço" },
    { key: "staff", label: "Profissional" },
    { key: "datetime", label: "Data e Hora" },
    { key: "confirm", label: "Confirmação" },
  ];

  const currentStepIndex = steps.findIndex(s => s.key === step);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        {step !== "service" && (
          <Button variant="ghost" size="icon" onClick={goBack} data-testid="button-back">
            <ArrowLeft className="w-5 h-5" />
          </Button>
        )}
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-page-title">Agendar Horário</h1>
          <p className="text-muted-foreground">Escolha seu serviço e horário</p>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        {steps.map((s, index) => (
          <div key={s.key} className="flex items-center shrink-0">
            <div className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
              index === currentStepIndex 
                ? "bg-primary text-primary-foreground" 
                : index < currentStepIndex 
                  ? "bg-primary/20 text-primary" 
                  : "bg-muted text-muted-foreground"
            }`}>
              {index < currentStepIndex ? (
                <Check className="w-4 h-4" />
              ) : (
                <span className="w-5 h-5 rounded-full border-2 flex items-center justify-center text-xs font-bold">
                  {index + 1}
                </span>
              )}
              <span className="text-sm font-medium">{s.label}</span>
            </div>
            {index < steps.length - 1 && (
              <ChevronRight className="w-4 h-4 mx-1 text-muted-foreground shrink-0" />
            )}
          </div>
        ))}
      </div>

      {/* Step Content */}
      {step === "service" && (
        <div className="space-y-4">
          <h2 className="text-lg font-semibold">Escolha o serviço</h2>
          {loadingServices ? (
            <div className="grid md:grid-cols-2 gap-4">
              {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-24" />)}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 gap-4">
              {services?.filter(s => s.isActive).map(service => (
                <Card 
                  key={service.id}
                  className={`cursor-pointer hover-elevate ${
                    selectedService?.id === service.id ? "ring-2 ring-primary" : ""
                  }`}
                  onClick={() => {
                    setSelectedService(service);
                    setStep("staff");
                  }}
                  data-testid={`card-select-service-${service.id}`}
                >
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Scissors className="w-6 h-6 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium truncate">{service.name}</h3>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground flex-wrap">
                        <span>{formatPrice(service.price)}</span>
                        <span>•</span>
                        <span>{formatDuration(service.duration)}</span>
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-muted-foreground shrink-0" />
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}

      {step === "staff" && (
        <div className="space-y-4">
          <h2 className="text-lg font-semibold">Escolha o profissional</h2>
          {loadingStaff ? (
            <div className="grid md:grid-cols-2 gap-4">
              {[1, 2, 3].map(i => <Skeleton key={i} className="h-20" />)}
            </div>
          ) : staff && staff.length > 0 ? (
            <div className="grid md:grid-cols-2 gap-4">
              {staff.map(member => (
                <Card 
                  key={member.id}
                  className={`cursor-pointer hover-elevate ${
                    selectedStaff?.id === member.id ? "ring-2 ring-primary" : ""
                  }`}
                  onClick={() => {
                    setSelectedStaff(member);
                    setStep("datetime");
                  }}
                  data-testid={`card-select-staff-${member.id}`}
                >
                  <CardContent className="p-4 flex items-center gap-4">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={member.profileImageUrl || undefined} />
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {member.firstName?.[0] || "P"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium truncate">
                        {member.firstName} {member.lastName}
                      </h3>
                      <p className="text-sm text-muted-foreground">Profissional</p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-muted-foreground shrink-0" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <User className="w-12 h-12 mx-auto text-muted-foreground/50 mb-4" />
                <p className="text-muted-foreground">Nenhum profissional disponível</p>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {step === "datetime" && (
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalendarIcon className="w-5 h-5" />
                Escolha a data
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                disabled={(date) => isBefore(date, new Date()) || isAfter(date, addDays(new Date(), 30))}
                locale={ptBR}
                className="rounded-lg border"
                data-testid="calendar-date"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Escolha o horário
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedDate ? (
                <div className="grid grid-cols-3 gap-2">
                  {generateTimeSlots().length > 0 ? (
                    generateTimeSlots().map(time => (
                      <Button
                        key={time}
                        variant={selectedTime === time ? "default" : "outline"}
                        onClick={() => setSelectedTime(time)}
                        data-testid={`button-time-${time}`}
                      >
                        {time}
                      </Button>
                    ))
                  ) : (
                    <p className="col-span-3 text-center text-muted-foreground py-8">
                      Nenhum horário disponível nesta data
                    </p>
                  )}
                </div>
              ) : (
                <p className="text-center text-muted-foreground py-8">
                  Selecione uma data primeiro
                </p>
              )}

              {selectedDate && selectedTime && (
                <Button 
                  className="w-full mt-4" 
                  onClick={() => setStep("confirm")}
                  data-testid="button-continue"
                >
                  Continuar
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {step === "confirm" && (
        <Card>
          <CardHeader>
            <CardTitle>Confirme seu agendamento</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-center gap-4 p-4 bg-muted/50 rounded-lg">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <Scissors className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Serviço</p>
                    <p className="font-medium">{selectedService?.name}</p>
                    <div className="flex items-center gap-2 text-sm">
                      <span className="text-primary font-semibold">
                        {selectedService && formatPrice(selectedService.price)}
                      </span>
                      <span className="text-muted-foreground">•</span>
                      <span className="text-muted-foreground">
                        {selectedService && formatDuration(selectedService.duration)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 bg-muted/50 rounded-lg">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={selectedStaff?.profileImageUrl || undefined} />
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {selectedStaff?.firstName?.[0] || "P"}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm text-muted-foreground">Profissional</p>
                    <p className="font-medium">
                      {selectedStaff?.firstName} {selectedStaff?.lastName}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 bg-muted/50 rounded-lg">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <CalendarIcon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Data e Hora</p>
                    <p className="font-medium">
                      {selectedDate && format(selectedDate, "EEEE, d 'de' MMMM", { locale: ptBR })}
                    </p>
                    <p className="text-sm text-muted-foreground">{selectedTime}</p>
                  </div>
                </div>
              </div>

              <div>
                <Label htmlFor="notes">Observações (opcional)</Label>
                <Textarea
                  id="notes"
                  placeholder="Alguma informação adicional..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="mt-2"
                  rows={5}
                  data-testid="input-notes"
                />
              </div>
            </div>

            <Button 
              className="w-full" 
              size="lg" 
              onClick={handleConfirm}
              disabled={createAppointment.isPending}
              data-testid="button-confirm"
            >
              {createAppointment.isPending ? "Agendando..." : "Confirmar Agendamento"}
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
