import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Calendar, 
  Clock, 
  Scissors, 
  User,
  Plus,
  X,
  CheckCircle,
  AlertCircle
} from "lucide-react";
import type { Appointment, Service, User as UserType } from "@shared/schema";
import { format, isPast, isFuture, isToday } from "date-fns";
import { ptBR } from "date-fns/locale";
import { motion } from "framer-motion";

export default function Appointments() {
  const { toast } = useToast();

  const { data: appointments, isLoading } = useQuery<(Appointment & { service?: Service; staff?: UserType })[]>({
    queryKey: ["/api/appointments/my"],
  });

  const cancelAppointment = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("PATCH", `/api/appointments/${id}/cancel`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      toast({
        title: "Agendamento cancelado",
        description: "Seu agendamento foi cancelado com sucesso.",
      });
    },
    onError: () => {
      toast({
        title: "Erro ao cancelar",
        description: "Tente novamente mais tarde.",
        variant: "destructive",
      });
    },
  });

  const upcomingAppointments = appointments?.filter(a => 
    isFuture(new Date(a.date)) && a.status !== "cancelled"
  ) || [];

  const pastAppointments = appointments?.filter(a => 
    isPast(new Date(a.date)) || a.status === "completed" || a.status === "cancelled"
  ) || [];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "confirmed":
        return <Badge className="bg-chart-5"><CheckCircle className="w-3 h-3 mr-1" />Confirmado</Badge>;
      case "pending":
        return <Badge variant="secondary"><Clock className="w-3 h-3 mr-1" />Pendente</Badge>;
      case "in_progress":
        return <Badge className="bg-chart-3"><Scissors className="w-3 h-3 mr-1" />Em Atendimento</Badge>;
      case "completed":
        return <Badge variant="outline"><CheckCircle className="w-3 h-3 mr-1" />Concluído</Badge>;
      case "cancelled":
        return <Badge variant="destructive"><X className="w-3 h-3 mr-1" />Cancelado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-page-title">Meus Agendamentos</h1>
          <p className="text-muted-foreground">Gerencie suas reservas</p>
        </div>
        <Button asChild>
          <Link href="/booking" data-testid="button-new-appointment">
            <Plus className="w-4 h-4 mr-2" />
            Novo Agendamento
          </Link>
        </Button>
      </div>

      <Tabs defaultValue="upcoming">
        <TabsList>
          <TabsTrigger value="upcoming" data-testid="tab-upcoming">
            Próximos ({upcomingAppointments.length})
          </TabsTrigger>
          <TabsTrigger value="past" data-testid="tab-past">
            Histórico ({pastAppointments.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming" className="mt-6 space-y-4">
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map(i => <Skeleton key={i} className="h-32" />)}
            </div>
          ) : upcomingAppointments.length > 0 ? (
            upcomingAppointments.map((appointment, index) => (
              <motion.div
                key={appointment.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <AppointmentCard 
                  appointment={appointment} 
                  onCancel={() => cancelAppointment.mutate(appointment.id)}
                  isPending={cancelAppointment.isPending}
                />
              </motion.div>
            ))
          ) : (
            <EmptyState />
          )}
        </TabsContent>

        <TabsContent value="past" className="mt-6 space-y-4">
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map(i => <Skeleton key={i} className="h-32" />)}
            </div>
          ) : pastAppointments.length > 0 ? (
            pastAppointments.map((appointment, index) => (
              <motion.div
                key={appointment.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <AppointmentCard 
                  appointment={appointment} 
                  isPast
                />
              </motion.div>
            ))
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              <Calendar className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>Nenhum histórico de agendamentos</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function AppointmentCard({ 
  appointment, 
  onCancel, 
  isPending = false,
  isPast = false 
}: { 
  appointment: Appointment & { service?: Service; staff?: UserType };
  onCancel?: () => void;
  isPending?: boolean;
  isPast?: boolean;
}) {
  const appointmentDate = new Date(appointment.date);
  const canCancel = !isPast && appointment.status !== "cancelled" && appointment.status !== "completed";

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "confirmed":
        return <Badge className="bg-chart-5"><CheckCircle className="w-3 h-3 mr-1" />Confirmado</Badge>;
      case "pending":
        return <Badge variant="secondary"><Clock className="w-3 h-3 mr-1" />Pendente</Badge>;
      case "in_progress":
        return <Badge className="bg-chart-3"><Scissors className="w-3 h-3 mr-1" />Em Atendimento</Badge>;
      case "completed":
        return <Badge variant="outline"><CheckCircle className="w-3 h-3 mr-1" />Concluído</Badge>;
      case "cancelled":
        return <Badge variant="destructive"><X className="w-3 h-3 mr-1" />Cancelado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <Card className={`overflow-hidden ${isPast ? "opacity-80" : ""}`} data-testid={`appointment-card-${appointment.id}`}>
      <CardContent className="p-0">
        <div className="flex flex-col md:flex-row">
          <div className={`md:w-24 p-4 flex flex-col items-center justify-center text-center ${
            isToday(appointmentDate) ? "bg-primary text-primary-foreground" : "bg-muted"
          }`}>
            <span className="text-sm uppercase">
              {format(appointmentDate, "EEE", { locale: ptBR })}
            </span>
            <span className="text-3xl font-bold">
              {format(appointmentDate, "d")}
            </span>
            <span className="text-sm">
              {format(appointmentDate, "MMM", { locale: ptBR })}
            </span>
          </div>
          
          <div className="flex-1 p-4">
            <div className="flex flex-wrap items-start justify-between gap-2 mb-3">
              <div>
                <h3 className="font-semibold text-lg">
                  {appointment.service?.name || `Serviço #${appointment.serviceId}`}
                </h3>
                <p className="text-muted-foreground text-sm flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {format(appointmentDate, "HH:mm")}
                  {appointment.service && ` • ${appointment.service.duration} min`}
                </p>
              </div>
              {getStatusBadge(appointment.status)}
            </div>

            {appointment.staff && (
              <div className="flex items-center gap-2 mb-3">
                <User className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm">
                  {appointment.staff.firstName} {appointment.staff.lastName}
                </span>
              </div>
            )}

            {appointment.notes && (
              <p className="text-sm text-muted-foreground bg-muted p-2 rounded mb-3">
                {appointment.notes}
              </p>
            )}

            {canCancel && onCancel && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="sm"
                    disabled={isPending}
                    data-testid={`button-cancel-${appointment.id}`}
                  >
                    <X className="w-4 h-4 mr-2" />
                    Cancelar
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Cancelar Agendamento</AlertDialogTitle>
                    <AlertDialogDescription>
                      Tem certeza que deseja cancelar este agendamento? Esta ação não pode ser desfeita.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Voltar</AlertDialogCancel>
                    <AlertDialogAction onClick={onCancel}>
                      Sim, cancelar
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function EmptyState() {
  return (
    <Card>
      <CardContent className="py-12 text-center">
        <Calendar className="w-16 h-16 mx-auto text-muted-foreground/30 mb-4" />
        <h3 className="text-lg font-medium mb-2">Nenhum agendamento</h3>
        <p className="text-muted-foreground mb-4">
          Você ainda não tem horários marcados
        </p>
        <Button asChild>
          <Link href="/booking">
            <Plus className="w-4 h-4 mr-2" />
            Agendar Agora
          </Link>
        </Button>
      </CardContent>
    </Card>
  );
}
