import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { 
  Tag, 
  Sparkles, 
  Clock, 
  Calendar,
  ArrowRight,
  Percent
} from "lucide-react";
import type { Promotion } from "@shared/schema";
import { format, differenceInDays, differenceInHours, isPast } from "date-fns";
import { ptBR } from "date-fns/locale";
import { motion } from "framer-motion";

export default function Promotions() {
  const { data: promotions, isLoading } = useQuery<Promotion[]>({
    queryKey: ["/api/promotions/active"],
  });

  const getTimeRemaining = (endDate: Date) => {
    const end = new Date(endDate);
    const days = differenceInDays(end, new Date());
    const hours = differenceInHours(end, new Date()) % 24;
    
    if (days > 0) {
      return `${days} dia${days > 1 ? "s" : ""} restante${days > 1 ? "s" : ""}`;
    } else if (hours > 0) {
      return `${hours} hora${hours > 1 ? "s" : ""} restante${hours > 1 ? "s" : ""}`;
    } else {
      return "Expira em breve!";
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-48" />
        <div className="grid md:grid-cols-2 gap-6">
          {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-64" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold" data-testid="text-page-title">Promoções</h1>
        <p className="text-muted-foreground">Ofertas especiais para você</p>
      </div>

      {promotions && promotions.length > 0 ? (
        <div className="grid md:grid-cols-2 gap-6">
          {promotions.map((promo, index) => (
            <motion.div
              key={promo.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <PromotionCard promotion={promo} />
            </motion.div>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="py-16 text-center">
            <Tag className="w-16 h-16 mx-auto text-muted-foreground/30 mb-4" />
            <h3 className="text-lg font-medium mb-2">Sem promoções no momento</h3>
            <p className="text-muted-foreground">
              Fique de olho! Novas ofertas em breve.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function PromotionCard({ promotion }: { promotion: Promotion }) {
  const endDate = new Date(promotion.endDate);
  const isExpiringSoon = differenceInDays(endDate, new Date()) <= 2;

  const getTimeRemaining = () => {
    const days = differenceInDays(endDate, new Date());
    const hours = differenceInHours(endDate, new Date()) % 24;
    
    if (days > 0) {
      return `${days} dia${days > 1 ? "s" : ""}`;
    } else if (hours > 0) {
      return `${hours} hora${hours > 1 ? "s" : ""}`;
    } else {
      return "Expira em breve!";
    }
  };

  return (
    <Card 
      className="overflow-hidden hover-elevate"
      data-testid={`promo-card-${promotion.id}`}
    >
      <div className="h-32 bg-gradient-to-br from-primary via-primary/80 to-chart-4 p-6 relative overflow-hidden">
        <div className="absolute top-4 right-4 opacity-20">
          <Percent className="w-24 h-24" />
        </div>
        <div className="relative z-10">
          {promotion.discountPercent ? (
            <div className="flex items-baseline gap-1">
              <span className="text-5xl font-bold text-primary-foreground">
                {promotion.discountPercent}%
              </span>
              <span className="text-xl text-primary-foreground/80">OFF</span>
            </div>
          ) : promotion.discountAmount ? (
            <div className="flex items-baseline gap-1">
              <span className="text-4xl font-bold text-primary-foreground">
                R$ {parseFloat(promotion.discountAmount).toFixed(0)}
              </span>
              <span className="text-lg text-primary-foreground/80">de desconto</span>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Sparkles className="w-8 h-8 text-primary-foreground" />
              <span className="text-2xl font-bold text-primary-foreground">Oferta Especial</span>
            </div>
          )}
        </div>
      </div>

      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-2 mb-3">
          <h3 className="font-bold text-lg">{promotion.title}</h3>
          {isExpiringSoon && (
            <Badge variant="destructive" className="shrink-0">
              <Clock className="w-3 h-3 mr-1" />
              Acaba logo
            </Badge>
          )}
        </div>

        {promotion.description && (
          <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
            {promotion.description}
          </p>
        )}

        <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground mb-4">
          <div className="flex items-center gap-1">
            <Calendar className="w-4 h-4" />
            <span>
              Até {format(endDate, "d 'de' MMMM", { locale: ptBR })}
            </span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            <span>{getTimeRemaining()}</span>
          </div>
        </div>

        <Button className="w-full" asChild>
          <Link href="/booking">
            Aproveitar Oferta
            <ArrowRight className="w-4 h-4 ml-2" />
          </Link>
        </Button>
      </CardContent>
    </Card>
  );
}
