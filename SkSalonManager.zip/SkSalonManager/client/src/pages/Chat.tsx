import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Send, 
  MessageCircle, 
  User,
  Check,
  CheckCheck,
  MoreVertical
} from "lucide-react";
import type { Message, User as UserType } from "@shared/schema";
import { format, isToday, isYesterday } from "date-fns";
import { ptBR } from "date-fns/locale";
import { motion, AnimatePresence } from "framer-motion";

export default function Chat() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedConversation, setSelectedConversation] = useState<UserType | null>(null);
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: conversations, isLoading: loadingConversations } = useQuery<UserType[]>({
    queryKey: ["/api/chat/conversations"],
  });

  const { data: messages, isLoading: loadingMessages, refetch: refetchMessages } = useQuery<Message[]>({
    queryKey: ["/api/chat/messages", selectedConversation?.id],
    enabled: !!selectedConversation,
    refetchInterval: 3000,
  });

  const sendMessage = useMutation({
    mutationFn: async (content: string) => {
      await apiRequest("POST", "/api/chat/messages", {
        receiverId: selectedConversation?.id,
        content,
      });
    },
    onSuccess: () => {
      setMessage("");
      queryClient.invalidateQueries({ queryKey: ["/api/chat/messages", selectedConversation?.id] });
    },
    onError: () => {
      toast({
        title: "Erro ao enviar mensagem",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (!message.trim() || !selectedConversation) return;
    sendMessage.mutate(message);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const formatMessageDate = (date: Date) => {
    const d = new Date(date);
    if (isToday(d)) return format(d, "HH:mm");
    if (isYesterday(d)) return "Ontem " + format(d, "HH:mm");
    return format(d, "dd/MM HH:mm");
  };

  const groupMessagesByDate = (msgs: Message[]) => {
    const groups: { [key: string]: Message[] } = {};
    msgs.forEach(msg => {
      const date = format(new Date(msg.createdAt!), "yyyy-MM-dd");
      if (!groups[date]) groups[date] = [];
      groups[date].push(msg);
    });
    return groups;
  };

  const formatGroupDate = (dateStr: string) => {
    const date = new Date(dateStr);
    if (isToday(date)) return "Hoje";
    if (isYesterday(date)) return "Ontem";
    return format(date, "d 'de' MMMM", { locale: ptBR });
  };

  return (
    <div className="h-[calc(100vh-12rem)] flex flex-col md:flex-row gap-4">
      {/* Conversations List */}
      <Card className={`md:w-80 shrink-0 flex flex-col ${selectedConversation ? "hidden md:flex" : "flex"}`}>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5" />
            Conversas
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 p-0 overflow-hidden">
          <ScrollArea className="h-full">
            {loadingConversations ? (
              <div className="p-4 space-y-3">
                {[1, 2, 3].map(i => <Skeleton key={i} className="h-16" />)}
              </div>
            ) : conversations && conversations.length > 0 ? (
              <div className="divide-y">
                {conversations.map(conv => (
                  <button
                    key={conv.id}
                    onClick={() => setSelectedConversation(conv)}
                    className={`w-full p-4 flex items-center gap-3 hover-elevate text-left transition-colors ${
                      selectedConversation?.id === conv.id ? "bg-accent" : ""
                    }`}
                    data-testid={`conversation-${conv.id}`}
                  >
                    <Avatar>
                      <AvatarImage src={conv.profileImageUrl || undefined} />
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {conv.firstName?.[0] || conv.email?.[0]?.toUpperCase() || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">
                        {conv.firstName} {conv.lastName}
                      </p>
                      <p className="text-sm text-muted-foreground truncate">
                        {conv.role === "admin" ? "Administrador" : conv.role === "staff" ? "Profissional" : "Cliente"}
                      </p>
                    </div>
                    {conv.role === "admin" && (
                      <Badge variant="secondary" className="shrink-0">Admin</Badge>
                    )}
                  </button>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center text-muted-foreground">
                <MessageCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>Nenhuma conversa</p>
                <p className="text-sm mt-1">As conversas aparecerão aqui</p>
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Chat Area */}
      <Card className={`flex-1 flex flex-col ${!selectedConversation ? "hidden md:flex" : "flex"}`}>
        {selectedConversation ? (
          <>
            <CardHeader className="border-b shrink-0 flex flex-row items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden shrink-0"
                onClick={() => setSelectedConversation(null)}
                data-testid="button-back-to-list"
              >
                <MessageCircle className="w-5 h-5" />
              </Button>
              <Avatar>
                <AvatarImage src={selectedConversation.profileImageUrl || undefined} />
                <AvatarFallback className="bg-primary/10 text-primary">
                  {selectedConversation.firstName?.[0] || "U"}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="font-semibold truncate" data-testid="text-chat-partner">
                  {selectedConversation.firstName} {selectedConversation.lastName}
                </p>
                <p className="text-sm text-muted-foreground">
                  {selectedConversation.role === "admin" ? "Administrador" : "Online"}
                </p>
              </div>
              <Button variant="ghost" size="icon">
                <MoreVertical className="w-5 h-5" />
              </Button>
            </CardHeader>

            <CardContent className="flex-1 p-0 overflow-hidden">
              <ScrollArea className="h-full p-4">
                {loadingMessages ? (
                  <div className="space-y-4">
                    {[1, 2, 3, 4].map(i => (
                      <div key={i} className={`flex ${i % 2 === 0 ? "justify-end" : "justify-start"}`}>
                        <Skeleton className={`h-12 ${i % 2 === 0 ? "w-48" : "w-64"}`} />
                      </div>
                    ))}
                  </div>
                ) : messages && messages.length > 0 ? (
                  <div className="space-y-4">
                    {Object.entries(groupMessagesByDate(messages)).map(([date, msgs]) => (
                      <div key={date}>
                        <div className="flex items-center justify-center my-4">
                          <Badge variant="outline" className="px-3 py-1">
                            {formatGroupDate(date)}
                          </Badge>
                        </div>
                        <AnimatePresence>
                          {msgs.map(msg => {
                            const isMe = msg.senderId === user?.id;
                            return (
                              <motion.div
                                key={msg.id}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                className={`flex mb-3 ${isMe ? "justify-end" : "justify-start"}`}
                              >
                                <div
                                  className={`max-w-[75%] p-3 rounded-lg ${
                                    isMe
                                      ? "bg-primary text-primary-foreground rounded-br-sm"
                                      : "bg-muted rounded-bl-sm"
                                  }`}
                                  data-testid={`message-${msg.id}`}
                                >
                                  <p className="break-words">{msg.content}</p>
                                  <div className={`flex items-center gap-1 mt-1 text-xs ${
                                    isMe ? "text-primary-foreground/70" : "text-muted-foreground"
                                  }`}>
                                    <span>{formatMessageDate(msg.createdAt!)}</span>
                                    {isMe && (
                                      msg.isRead ? (
                                        <CheckCheck className="w-3 h-3" />
                                      ) : (
                                        <Check className="w-3 h-3" />
                                      )
                                    )}
                                  </div>
                                </div>
                              </motion.div>
                            );
                          })}
                        </AnimatePresence>
                      </div>
                    ))}
                    <div ref={messagesEndRef} />
                  </div>
                ) : (
                  <div className="h-full flex items-center justify-center text-center text-muted-foreground">
                    <div>
                      <MessageCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>Inicie uma conversa</p>
                    </div>
                  </div>
                )}
              </ScrollArea>
            </CardContent>

            <div className="p-4 border-t shrink-0">
              <div className="flex gap-2">
                <Input
                  placeholder="Digite sua mensagem..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="flex-1"
                  data-testid="input-message"
                />
                <Button 
                  onClick={handleSend}
                  disabled={!message.trim() || sendMessage.isPending}
                  data-testid="button-send"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-center text-muted-foreground p-8">
            <div>
              <MessageCircle className="w-16 h-16 mx-auto mb-4 opacity-30" />
              <h2 className="text-xl font-semibold mb-2">Suas mensagens</h2>
              <p>Selecione uma conversa para começar</p>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
