import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ThemeToggle } from "@/components/ThemeToggle";
import { 
  Scissors, 
  Calendar, 
  Clock, 
  Star, 
  Phone, 
  MapPin, 
  Instagram, 
  Facebook,
  Users,
  Sparkles,
  Heart,
  ChevronRight,
  MessageCircle
} from "lucide-react";
import { motion } from "framer-motion";

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 }
};

const staggerContainer = {
  animate: { transition: { staggerChildren: 0.1 } }
};

export default function Landing() {
  const features = [
    {
      icon: Calendar,
      title: "Agendamento Online",
      description: "Marque seu horário a qualquer momento, de qualquer lugar"
    },
    {
      icon: Clock,
      title: "Fila em Tempo Real",
      description: "Acompanhe sua posição na fila antes de chegar"
    },
    {
      icon: Sparkles,
      title: "Promoções Exclusivas",
      description: "Descontos especiais para clientes cadastrados"
    },
    {
      icon: MessageCircle,
      title: "Chat Direto",
      description: "Converse diretamente com nossos profissionais"
    }
  ];

  const services = [
    { name: "Corte Masculino", price: "R$ 35", duration: "30 min" },
    { name: "Corte Feminino", price: "R$ 50", duration: "45 min" },
    { name: "Tranças Box Braids", price: "R$ 180", duration: "3h" },
    { name: "Hidratação", price: "R$ 60", duration: "1h" },
    { name: "Coloração", price: "R$ 120", duration: "2h" },
    { name: "Escova Progressiva", price: "R$ 150", duration: "2h30" }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
              <Scissors className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold" data-testid="text-logo">SKsalon</span>
          </div>
          <nav className="hidden md:flex items-center gap-6 flex-wrap">
            <a href="#servicos" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-services">Serviços</a>
            <a href="#sobre" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-about">Sobre</a>
            <a href="#contato" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-contact">Contato</a>
          </nav>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button asChild data-testid="button-login">
              <a href="/api/login">Entrar</a>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-background to-accent/30" />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiM5Mzk1OTciIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDM0djJoLTJ2LTJoMnptMC00aDJ2Mmgtdnwtems0IDBoMnYyaC0ydi0yem00IDBoMnYyaC0ydi0yem0wIDRoMnYyaC0ydi0yem0wIDRoMnYyaC0ydi0yeiIvPjwvZz48L2c+PC9zdmc+')] opacity-50" />
        
        <motion.div 
          className="container mx-auto px-4 py-20 md:py-32 relative"
          initial="initial"
          animate="animate"
          variants={staggerContainer}
        >
          <div className="max-w-3xl mx-auto text-center">
            <motion.div variants={fadeInUp}>
              <Badge variant="secondary" className="mb-6">
                <Star className="w-3 h-3 mr-1" />
                Mais de 500 clientes satisfeitos
              </Badge>
            </motion.div>
            
            <motion.h1 
              className="text-4xl md:text-6xl font-bold mb-6 leading-tight"
              variants={fadeInUp}
              data-testid="text-hero-title"
            >
              Sua beleza merece o{" "}
              <span className="text-primary">melhor cuidado</span>
            </motion.h1>
            
            <motion.p 
              className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto"
              variants={fadeInUp}
              data-testid="text-hero-description"
            >
              No SKsalon, transformamos seu visual com profissionalismo e carinho. 
              Agende online, acompanhe a fila e desfrute de uma experiência única.
            </motion.p>
            
            <motion.div 
              className="flex flex-col sm:flex-row gap-4 justify-center flex-wrap"
              variants={fadeInUp}
            >
              <Button size="lg" asChild data-testid="button-schedule-now">
                <a href="/api/login">
                  Agendar Agora
                  <ChevronRight className="w-4 h-4 ml-1" />
                </a>
              </Button>
              <Button size="lg" variant="outline" asChild data-testid="button-view-services">
                <a href="#servicos">Ver Serviços</a>
              </Button>
            </motion.div>
          </div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-24 bg-card/50">
        <div className="container mx-auto px-4">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Por que escolher o SKsalon?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Tecnologia e tradição unidos para oferecer a melhor experiência
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full hover-elevate">
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                      <feature.icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                    <p className="text-muted-foreground text-sm">{feature.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section id="servicos" className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Nossos Serviços</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Profissionais qualificados e produtos de alta qualidade
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service, index) => (
              <motion.div
                key={service.name}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="overflow-hidden hover-elevate" data-testid={`card-service-${index}`}>
                  <div className="h-40 bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                    <Scissors className="w-12 h-12 text-primary/50" />
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <h3 className="font-semibold text-lg">{service.name}</h3>
                      <Badge variant="secondary" className="shrink-0">
                        <Clock className="w-3 h-3 mr-1" />
                        {service.duration}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <span className="text-2xl font-bold text-primary">{service.price}</span>
                      <Button size="sm" asChild>
                        <a href="/api/login">Agendar</a>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-8">
            <Button variant="outline" size="lg" asChild>
              <a href="/api/login">
                Ver Todos os Serviços
                <ChevronRight className="w-4 h-4 ml-1" />
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="sobre" className="py-16 md:py-24 bg-card/50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Mais que um salão, uma <span className="text-primary">experiência</span>
              </h2>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                Há mais de 10 anos transformando vidas através da beleza. Nossa equipe de 
                profissionais altamente qualificados está pronta para atender você com 
                carinho e dedicação.
              </p>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    <Users className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-bold text-xl">500+</p>
                    <p className="text-muted-foreground text-sm">Clientes Felizes</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    <Heart className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-bold text-xl">10+</p>
                    <p className="text-muted-foreground text-sm">Anos de Experiência</p>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="aspect-square rounded-lg bg-gradient-to-br from-primary/30 via-accent/20 to-primary/10 flex items-center justify-center">
                <div className="text-center p-8">
                  <div className="w-24 h-24 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                    <Scissors className="w-12 h-12 text-primary" />
                  </div>
                  <p className="text-lg font-medium text-muted-foreground">
                    Insira seu logo aqui
                  </p>
                  <p className="text-sm text-muted-foreground mt-2">
                    Área para upload no painel admin
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contato" className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Entre em Contato</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Estamos prontos para atendê-lo
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <Card className="hover-elevate">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Phone className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">Telefone</h3>
                <p className="text-muted-foreground" data-testid="text-phone">(11) 99999-9999</p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <MapPin className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">Endereço</h3>
                <p className="text-muted-foreground" data-testid="text-address">Rua das Flores, 123</p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">Horário</h3>
                <p className="text-muted-foreground" data-testid="text-hours">Seg-Sáb: 9h - 19h</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <Scissors className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold">SKsalon</span>
            </div>
            
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" asChild>
                <a href="#" aria-label="Instagram" data-testid="link-instagram">
                  <Instagram className="w-5 h-5" />
                </a>
              </Button>
              <Button variant="ghost" size="icon" asChild>
                <a href="#" aria-label="Facebook" data-testid="link-facebook">
                  <Facebook className="w-5 h-5" />
                </a>
              </Button>
            </div>
            
            <p className="text-muted-foreground text-sm">
              © 2024 SKsalon. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
