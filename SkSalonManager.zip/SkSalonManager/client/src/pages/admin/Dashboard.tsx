import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Link } from "wouter";
import { 
  Users, 
  Calendar, 
  DollarSign, 
  TrendingUp,
  Scissors,
  ShoppingBag,
  Clock,
  Bell,
  ChevronRight,
  UserPlus,
  Tag
} from "lucide-react";
import type { Appointment, User, Queue } from "@shared/schema";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { motion } from "framer-motion";

export default function AdminDashboard() {
  const { data: stats, isLoading: loadingStats } = useQuery<{
    totalClients: number;
    todayAppointments: number;
    revenue: number;
    queueSize: number;
  }>({
    queryKey: ["/api/admin/stats"],
  });

  const { data: recentAppointments, isLoading: loadingAppointments } = useQuery<Appointment[]>({
    queryKey: ["/api/admin/appointments/recent"],
  });

  const { data: recentClients, isLoading: loadingClients } = useQuery<User[]>({
    queryKey: ["/api/admin/clients/recent"],
  });

  const { data: currentQueue, isLoading: loadingQueue } = useQuery<Queue[]>({
    queryKey: ["/api/queue"],
  });

  const statCards = [
    {
      title: "Total de Clientes",
      value: stats?.totalClients || 0,
      icon: Users,
      color: "bg-chart-3/10 text-chart-3",
      trend: "+12%",
      trendUp: true,
    },
    {
      title: "Agendamentos Hoje",
      value: stats?.todayAppointments || 0,
      icon: Calendar,
      color: "bg-chart-4/10 text-chart-4",
      trend: "+5%",
      trendUp: true,
    },
    {
      title: "Receita do Mês",
      value: `R$ ${(stats?.revenue || 0).toLocaleString("pt-BR")}`,
      icon: DollarSign,
      color: "bg-chart-5/10 text-chart-5",
      trend: "+18%",
      trendUp: true,
    },
    {
      title: "Fila Atual",
      value: stats?.queueSize || currentQueue?.length || 0,
      icon: Clock,
      color: "bg-primary/10 text-primary",
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-page-title">Painel Administrativo</h1>
          <p className="text-muted-foreground">Visão geral do salão</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" asChild>
            <Link href="/admin/queue" data-testid="link-manage-queue">
              <Users className="w-4 h-4 mr-2" />
              Gerenciar Fila
            </Link>
          </Button>
          <Button asChild>
            <Link href="/admin/appointments" data-testid="link-new-appointment">
              <Calendar className="w-4 h-4 mr-2" />
              Agendamentos
            </Link>
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {loadingStats ? (
          [1, 2, 3, 4].map(i => <Skeleton key={i} className="h-32" />)
        ) : (
          statCards.map((stat, index) => (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="hover-elevate">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className={`w-10 h-10 rounded-lg ${stat.color} flex items-center justify-center`}>
                      <stat.icon className="w-5 h-5" />
                    </div>
                    {stat.trend && (
                      <Badge variant={stat.trendUp ? "default" : "destructive"} className="text-xs">
                        <TrendingUp className={`w-3 h-3 mr-1 ${!stat.trendUp ? "rotate-180" : ""}`} />
                        {stat.trend}
                      </Badge>
                    )}
                  </div>
                  <p className="text-2xl font-bold" data-testid={`stat-${stat.title.toLowerCase().replace(/\s/g, "-")}`}>
                    {stat.value}
                  </p>
                  <p className="text-sm text-muted-foreground">{stat.title}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))
        )}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Recent Appointments */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2">
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" />
              Agendamentos Recentes
            </CardTitle>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/appointments">
                Ver todos
                <ChevronRight className="w-4 h-4 ml-1" />
              </Link>
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {loadingAppointments ? (
              [1, 2, 3].map(i => <Skeleton key={i} className="h-16" />)
            ) : recentAppointments && recentAppointments.length > 0 ? (
              recentAppointments.slice(0, 5).map(appointment => (
                <div 
                  key={appointment.id} 
                  className="flex items-center gap-4 p-3 rounded-lg bg-muted/50"
                  data-testid={`appointment-row-${appointment.id}`}
                >
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    <Scissors className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">Cliente #{appointment.clientId?.slice(-4) || "---"}</p>
                    <p className="text-sm text-muted-foreground">
                      {format(new Date(appointment.date), "dd/MM HH:mm", { locale: ptBR })}
                    </p>
                  </div>
                  <Badge variant={
                    appointment.status === "confirmed" ? "default" :
                    appointment.status === "pending" ? "secondary" :
                    "outline"
                  }>
                    {appointment.status === "confirmed" ? "Confirmado" :
                     appointment.status === "pending" ? "Pendente" :
                     appointment.status === "completed" ? "Concluído" :
                     appointment.status}
                  </Badge>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Calendar className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>Nenhum agendamento recente</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Current Queue */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2">
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-chart-4" />
              Fila de Atendimento
            </CardTitle>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/queue">
                Gerenciar
                <ChevronRight className="w-4 h-4 ml-1" />
              </Link>
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {loadingQueue ? (
              [1, 2, 3].map(i => <Skeleton key={i} className="h-16" />)
            ) : currentQueue && currentQueue.length > 0 ? (
              currentQueue.filter(q => q.status !== "completed").slice(0, 5).map((item, index) => (
                <div 
                  key={item.id} 
                  className={`flex items-center gap-4 p-3 rounded-lg ${
                    item.status === "in_service" ? "bg-chart-5/10" :
                    item.status === "called" ? "bg-chart-4/10 animate-pulse" :
                    "bg-muted/50"
                  }`}
                  data-testid={`queue-row-${item.id}`}
                >
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                    item.status === "in_service" ? "bg-chart-5 text-white" :
                    item.status === "called" ? "bg-chart-4 text-white" :
                    "bg-primary/10 text-primary"
                  }`}>
                    #{item.position}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">Cliente #{item.clientId?.slice(-4) || "---"}</p>
                    <p className="text-sm text-muted-foreground">
                      Serviço #{item.serviceId}
                    </p>
                  </div>
                  <Badge variant={
                    item.status === "in_service" ? "default" :
                    item.status === "called" ? "secondary" :
                    "outline"
                  }>
                    {item.status === "in_service" ? "Atendendo" :
                     item.status === "called" ? "Chamado" :
                     "Aguardando"}
                  </Badge>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Users className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>Nenhum cliente na fila</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Link href="/admin/services">
          <Card className="hover-elevate cursor-pointer h-full">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-chart-2/10 flex items-center justify-center shrink-0">
                <Scissors className="w-6 h-6 text-chart-2" />
              </div>
              <div>
                <p className="font-semibold">Serviços</p>
                <p className="text-sm text-muted-foreground">Gerenciar catálogo</p>
              </div>
            </CardContent>
          </Card>
        </Link>
        <Link href="/admin/products">
          <Card className="hover-elevate cursor-pointer h-full">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-chart-3/10 flex items-center justify-center shrink-0">
                <ShoppingBag className="w-6 h-6 text-chart-3" />
              </div>
              <div>
                <p className="font-semibold">Produtos</p>
                <p className="text-sm text-muted-foreground">Estoque e vendas</p>
              </div>
            </CardContent>
          </Card>
        </Link>
        <Link href="/admin/promotions">
          <Card className="hover-elevate cursor-pointer h-full">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-chart-4/10 flex items-center justify-center shrink-0">
                <Tag className="w-6 h-6 text-chart-4" />
              </div>
              <div>
                <p className="font-semibold">Promoções</p>
                <p className="text-sm text-muted-foreground">Ofertas e descontos</p>
              </div>
            </CardContent>
          </Card>
        </Link>
        <Link href="/admin/settings">
          <Card className="hover-elevate cursor-pointer h-full">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <Bell className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="font-semibold">Configurações</p>
                <p className="text-sm text-muted-foreground">Logo e horários</p>
              </div>
            </CardContent>
          </Card>
        </Link>
      </div>

      {/* Recent Clients */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2">
          <CardTitle className="flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-chart-5" />
            Clientes Recentes
          </CardTitle>
          <Button variant="ghost" size="sm" asChild>
            <Link href="/admin/clients">
              Ver todos
              <ChevronRight className="w-4 h-4 ml-1" />
            </Link>
          </Button>
        </CardHeader>
        <CardContent>
          {loadingClients ? (
            <div className="flex gap-4 overflow-x-auto pb-2">
              {[1, 2, 3, 4, 5].map(i => <Skeleton key={i} className="w-20 h-24 shrink-0" />)}
            </div>
          ) : recentClients && recentClients.length > 0 ? (
            <div className="flex gap-4 overflow-x-auto pb-2">
              {recentClients.slice(0, 8).map(client => (
                <div 
                  key={client.id} 
                  className="flex flex-col items-center gap-2 shrink-0"
                  data-testid={`client-avatar-${client.id}`}
                >
                  <Avatar className="w-14 h-14">
                    <AvatarImage src={client.profileImageUrl || undefined} />
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {client.firstName?.[0] || client.email?.[0]?.toUpperCase() || "C"}
                    </AvatarFallback>
                  </Avatar>
                  <p className="text-xs text-center font-medium max-w-[80px] truncate">
                    {client.firstName || "Cliente"}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Users className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>Nenhum cliente cadastrado</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
