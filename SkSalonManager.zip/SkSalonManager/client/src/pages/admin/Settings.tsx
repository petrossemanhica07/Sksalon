import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Settings, 
  Image, 
  Phone, 
  MapPin, 
  Clock,
  Save,
  Upload,
  Instagram,
  Facebook,
  Globe
} from "lucide-react";
import type { SalonSetting } from "@shared/schema";

export default function AdminSettings() {
  const { toast } = useToast();
  
  const [settings, setSettings] = useState({
    salonName: "SKsalon",
    phone: "(11) 99999-9999",
    address: "Rua das Flores, 123",
    workingHours: "Seg-Sáb: 9h - 19h",
    instagram: "",
    facebook: "",
    website: "",
    description: "",
    logoUrl: "",
  });

  const { data: savedSettings, isLoading } = useQuery<SalonSetting[]>({
    queryKey: ["/api/admin/settings"],
  });

  const saveSettings = useMutation({
    mutationFn: async (data: typeof settings) => {
      await apiRequest("POST", "/api/admin/settings", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/settings"] });
      toast({ title: "Configurações salvas!" });
    },
    onError: () => {
      toast({ title: "Erro ao salvar", variant: "destructive" });
    },
  });

  useEffect(() => {
    if (savedSettings) {
      const settingsMap: Record<string, string> = {};
      savedSettings.forEach(s => {
        settingsMap[s.key] = s.value || "";
      });
      setSettings(prev => ({
        ...prev,
        ...settingsMap,
      }));
    }
  }, [savedSettings]);

  const handleSave = () => {
    saveSettings.mutate(settings);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-64" />
        <Skeleton className="h-64" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-page-title">Configurações</h1>
          <p className="text-muted-foreground">Gerencie as informações do salão</p>
        </div>
        <Button onClick={handleSave} disabled={saveSettings.isPending} data-testid="button-save">
          <Save className="w-4 h-4 mr-2" />
          {saveSettings.isPending ? "Salvando..." : "Salvar"}
        </Button>
      </div>

      {/* Logo Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Image className="w-5 h-5" />
            Logo do Salão
          </CardTitle>
          <CardDescription>
            Faça upload do logotipo do seu salão
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div className="w-32 h-32 rounded-lg border-2 border-dashed border-muted-foreground/30 flex items-center justify-center bg-muted/50">
              {settings.logoUrl ? (
                <img 
                  src={settings.logoUrl} 
                  alt="Logo" 
                  className="w-full h-full object-contain rounded-lg"
                />
              ) : (
                <div className="text-center text-muted-foreground">
                  <Image className="w-8 h-8 mx-auto mb-2" />
                  <p className="text-xs">Sem logo</p>
                </div>
              )}
            </div>
            <div className="flex-1 space-y-3">
              <div>
                <Label htmlFor="logoUrl">URL do Logo</Label>
                <Input
                  id="logoUrl"
                  value={settings.logoUrl}
                  onChange={(e) => setSettings({ ...settings, logoUrl: e.target.value })}
                  placeholder="https://exemplo.com/logo.png"
                  data-testid="input-logo-url"
                />
              </div>
              <p className="text-sm text-muted-foreground">
                Insira a URL de uma imagem para usar como logo
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Basic Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Informações Básicas
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="salonName">Nome do Salão</Label>
            <Input
              id="salonName"
              value={settings.salonName}
              onChange={(e) => setSettings({ ...settings, salonName: e.target.value })}
              placeholder="SKsalon"
              data-testid="input-salon-name"
            />
          </div>
          <div>
            <Label htmlFor="description">Descrição</Label>
            <Textarea
              id="description"
              value={settings.description}
              onChange={(e) => setSettings({ ...settings, description: e.target.value })}
              placeholder="Descreva seu salão..."
              rows={3}
              data-testid="input-description"
            />
          </div>
        </CardContent>
      </Card>

      {/* Contact Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Phone className="w-5 h-5" />
            Contato
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="phone">Telefone</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="phone"
                  value={settings.phone}
                  onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
                  placeholder="(11) 99999-9999"
                  className="pl-10"
                  data-testid="input-phone"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="workingHours">Horário de Funcionamento</Label>
              <div className="relative">
                <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="workingHours"
                  value={settings.workingHours}
                  onChange={(e) => setSettings({ ...settings, workingHours: e.target.value })}
                  placeholder="Seg-Sáb: 9h - 19h"
                  className="pl-10"
                  data-testid="input-hours"
                />
              </div>
            </div>
          </div>
          <div>
            <Label htmlFor="address">Endereço</Label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                id="address"
                value={settings.address}
                onChange={(e) => setSettings({ ...settings, address: e.target.value })}
                placeholder="Rua das Flores, 123"
                className="pl-10"
                data-testid="input-address"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Social Media */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="w-5 h-5" />
            Redes Sociais
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="instagram">Instagram</Label>
            <div className="relative">
              <Instagram className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                id="instagram"
                value={settings.instagram}
                onChange={(e) => setSettings({ ...settings, instagram: e.target.value })}
                placeholder="https://instagram.com/sksalon"
                className="pl-10"
                data-testid="input-instagram"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="facebook">Facebook</Label>
            <div className="relative">
              <Facebook className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                id="facebook"
                value={settings.facebook}
                onChange={(e) => setSettings({ ...settings, facebook: e.target.value })}
                placeholder="https://facebook.com/sksalon"
                className="pl-10"
                data-testid="input-facebook"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="website">Website</Label>
            <div className="relative">
              <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                id="website"
                value={settings.website}
                onChange={(e) => setSettings({ ...settings, website: e.target.value })}
                placeholder="https://sksalon.com"
                className="pl-10"
                data-testid="input-website"
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
