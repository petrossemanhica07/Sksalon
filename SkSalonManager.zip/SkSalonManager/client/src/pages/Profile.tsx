import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Link } from "wouter";
import { 
  User, 
  Mail, 
  Phone, 
  Calendar, 
  Settings, 
  LogOut,
  ChevronRight,
  Clock,
  Star,
  Heart
} from "lucide-react";
import type { Appointment } from "@shared/schema";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function Profile() {
  const { user } = useAuth();

  const { data: appointments } = useQuery<Appointment[]>({
    queryKey: ["/api/appointments/my"],
  });

  const completedAppointments = appointments?.filter(a => a.status === "completed").length || 0;
  const memberSince = user?.createdAt ? format(new Date(user.createdAt), "MMMM 'de' yyyy", { locale: ptBR }) : "2024";

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      {/* Profile Header */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <Avatar className="w-24 h-24">
              <AvatarImage src={user?.profileImageUrl || undefined} alt={user?.firstName || "User"} />
              <AvatarFallback className="bg-primary text-primary-foreground text-2xl">
                {user?.firstName?.[0] || user?.email?.[0]?.toUpperCase() || "U"}
              </AvatarFallback>
            </Avatar>
            <div className="text-center sm:text-left flex-1">
              <h1 className="text-2xl font-bold" data-testid="text-user-name">
                {user?.firstName} {user?.lastName}
              </h1>
              <p className="text-muted-foreground">{user?.email}</p>
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mt-3">
                <Badge variant="secondary">
                  <Star className="w-3 h-3 mr-1" />
                  Cliente VIP
                </Badge>
                <Badge variant="outline">
                  <Calendar className="w-3 h-3 mr-1" />
                  Desde {memberSince}
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-2">
              <Calendar className="w-5 h-5 text-primary" />
            </div>
            <p className="text-2xl font-bold" data-testid="text-appointments-count">
              {appointments?.length || 0}
            </p>
            <p className="text-sm text-muted-foreground">Agendamentos</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-10 h-10 rounded-full bg-chart-5/10 flex items-center justify-center mx-auto mb-2">
              <Clock className="w-5 h-5 text-chart-5" />
            </div>
            <p className="text-2xl font-bold" data-testid="text-completed-count">
              {completedAppointments}
            </p>
            <p className="text-sm text-muted-foreground">Concluídos</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-10 h-10 rounded-full bg-chart-4/10 flex items-center justify-center mx-auto mb-2">
              <Heart className="w-5 h-5 text-chart-4" />
            </div>
            <p className="text-2xl font-bold">5</p>
            <p className="text-sm text-muted-foreground">Favoritos</p>
          </CardContent>
        </Card>
      </div>

      {/* Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="w-5 h-5" />
            Informações
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Mail className="w-5 h-5 text-muted-foreground shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm text-muted-foreground">E-mail</p>
              <p className="font-medium truncate" data-testid="text-email">{user?.email || "Não informado"}</p>
            </div>
          </div>
          <Separator />
          <div className="flex items-center gap-4">
            <Phone className="w-5 h-5 text-muted-foreground shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm text-muted-foreground">Telefone</p>
              <p className="font-medium" data-testid="text-phone">{user?.phone || "Não informado"}</p>
            </div>
          </div>
          <Separator />
          <div className="flex items-center gap-4">
            <Calendar className="w-5 h-5 text-muted-foreground shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm text-muted-foreground">Membro desde</p>
              <p className="font-medium">{memberSince}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Ações Rápidas
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Link href="/appointments">
            <div className="flex items-center gap-4 p-4 hover-elevate cursor-pointer">
              <Calendar className="w-5 h-5 text-muted-foreground" />
              <span className="flex-1">Meus Agendamentos</span>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </div>
          </Link>
          <Separator />
          <Link href="/notifications">
            <div className="flex items-center gap-4 p-4 hover-elevate cursor-pointer">
              <Mail className="w-5 h-5 text-muted-foreground" />
              <span className="flex-1">Notificações</span>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </div>
          </Link>
          <Separator />
          <a href="/api/logout">
            <div className="flex items-center gap-4 p-4 hover-elevate cursor-pointer text-destructive">
              <LogOut className="w-5 h-5" />
              <span className="flex-1">Sair da Conta</span>
              <ChevronRight className="w-5 h-5" />
            </div>
          </a>
        </CardContent>
      </Card>
    </div>
  );
}
