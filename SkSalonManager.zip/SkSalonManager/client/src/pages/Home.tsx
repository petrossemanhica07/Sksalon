import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { 
  Calendar, 
  Clock, 
  Users, 
  Scissors, 
  ShoppingBag,
  Bell,
  MessageCircle,
  Sparkles,
  ChevronRight,
  Tag
} from "lucide-react";
import type { Appointment, Promotion, Queue, Notification } from "@shared/schema";

export default function Home() {
  const { user } = useAuth();

  const { data: appointments, isLoading: loadingAppointments } = useQuery<Appointment[]>({
    queryKey: ["/api/appointments/my"],
  });

  const { data: queueStatus, isLoading: loadingQueue } = useQuery<Queue | null>({
    queryKey: ["/api/queue/my-position"],
  });

  const { data: promotions, isLoading: loadingPromotions } = useQuery<Promotion[]>({
    queryKey: ["/api/promotions/active"],
  });

  const { data: notifications, isLoading: loadingNotifications } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
  });

  const unreadNotifications = notifications?.filter(n => !n.isRead).length || 0;

  const quickActions = [
    { icon: Calendar, label: "Agendar", href: "/booking", color: "bg-primary/10 text-primary" },
    { icon: Users, label: "Fila", href: "/queue", color: "bg-chart-2/10 text-chart-2" },
    { icon: MessageCircle, label: "Chat", href: "/chat", color: "bg-chart-3/10 text-chart-3" },
    { icon: ShoppingBag, label: "Produtos", href: "/products", color: "bg-chart-4/10 text-chart-4" },
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Avatar className="w-14 h-14">
            <AvatarImage src={user?.profileImageUrl || undefined} alt={user?.firstName || "User"} />
            <AvatarFallback className="bg-primary text-primary-foreground text-lg">
              {user?.firstName?.[0] || user?.email?.[0]?.toUpperCase() || "U"}
            </AvatarFallback>
          </Avatar>
          <div>
            <h1 className="text-2xl font-bold" data-testid="text-welcome">
              Olá, {user?.firstName || "Cliente"}!
            </h1>
            <p className="text-muted-foreground">Bem-vindo ao SKsalon</p>
          </div>
        </div>
        <Button variant="outline" asChild className="relative">
          <Link href="/notifications" data-testid="button-notifications">
            <Bell className="w-4 h-4 mr-2" />
            Notificações
            {unreadNotifications > 0 && (
              <Badge className="absolute -top-2 -right-2 h-5 w-5 p-0 flex items-center justify-center text-xs">
                {unreadNotifications}
              </Badge>
            )}
          </Link>
        </Button>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {quickActions.map((action) => (
          <Link key={action.href} href={action.href}>
            <Card className="hover-elevate cursor-pointer" data-testid={`card-action-${action.label.toLowerCase()}`}>
              <CardContent className="p-4 text-center">
                <div className={`w-12 h-12 rounded-full ${action.color} flex items-center justify-center mx-auto mb-3`}>
                  <action.icon className="w-6 h-6" />
                </div>
                <p className="font-medium">{action.label}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {/* Queue Status */}
      {queueStatus && (
        <Card className="border-primary/20 bg-primary/5">
          <CardContent className="p-6">
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center">
                  <span className="text-2xl font-bold text-primary-foreground">
                    #{queueStatus.position}
                  </span>
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Você está na fila!</h3>
                  <p className="text-muted-foreground">
                    Tempo estimado: {queueStatus.estimatedWait || "Calculando..."} min
                  </p>
                </div>
              </div>
              <Button variant="outline" asChild>
                <Link href="/queue">Ver Detalhes</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Upcoming Appointments */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-4">
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" />
              Próximos Agendamentos
            </CardTitle>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/appointments">
                Ver todos
                <ChevronRight className="w-4 h-4 ml-1" />
              </Link>
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {loadingAppointments ? (
              <>
                <Skeleton className="h-20" />
                <Skeleton className="h-20" />
              </>
            ) : appointments && appointments.length > 0 ? (
              appointments.slice(0, 3).map((appointment) => (
                <div 
                  key={appointment.id} 
                  className="flex items-center gap-4 p-3 rounded-lg bg-card hover-elevate"
                  data-testid={`card-appointment-${appointment.id}`}
                >
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <Scissors className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">Serviço #{appointment.serviceId}</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(appointment.date).toLocaleDateString("pt-BR", {
                        weekday: "short",
                        day: "numeric",
                        month: "short",
                        hour: "2-digit",
                        minute: "2-digit"
                      })}
                    </p>
                  </div>
                  <Badge variant={
                    appointment.status === "confirmed" ? "default" :
                    appointment.status === "pending" ? "secondary" :
                    "outline"
                  }>
                    {appointment.status === "confirmed" ? "Confirmado" :
                     appointment.status === "pending" ? "Pendente" :
                     appointment.status}
                  </Badge>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Calendar className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>Nenhum agendamento</p>
                <Button variant="link" asChild className="mt-2">
                  <Link href="/booking">Agendar agora</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Active Promotions */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-4">
            <CardTitle className="flex items-center gap-2">
              <Tag className="w-5 h-5 text-chart-4" />
              Promoções
            </CardTitle>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/promotions">
                Ver todas
                <ChevronRight className="w-4 h-4 ml-1" />
              </Link>
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {loadingPromotions ? (
              <>
                <Skeleton className="h-24" />
                <Skeleton className="h-24" />
              </>
            ) : promotions && promotions.length > 0 ? (
              promotions.slice(0, 2).map((promo) => (
                <div 
                  key={promo.id} 
                  className="p-4 rounded-lg bg-gradient-to-r from-primary/10 to-chart-4/10 border border-primary/20 hover-elevate"
                  data-testid={`card-promo-${promo.id}`}
                >
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center shrink-0">
                      <Sparkles className="w-5 h-5 text-primary-foreground" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold truncate">{promo.title}</h4>
                      <p className="text-sm text-muted-foreground line-clamp-2">{promo.description}</p>
                      {promo.discountPercent && (
                        <Badge className="mt-2">{promo.discountPercent}% OFF</Badge>
                      )}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Tag className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>Nenhuma promoção ativa</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Services Preview */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2 pb-4">
          <CardTitle className="flex items-center gap-2">
            <Scissors className="w-5 h-5 text-chart-2" />
            Serviços Populares
          </CardTitle>
          <Button variant="ghost" size="sm" asChild>
            <Link href="/services">
              Ver todos
              <ChevronRight className="w-4 h-4 ml-1" />
            </Link>
          </Button>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {[
              { name: "Corte", icon: Scissors, price: "R$ 35" },
              { name: "Tranças", icon: Users, price: "R$ 180" },
              { name: "Hidratação", icon: Sparkles, price: "R$ 60" },
              { name: "Coloração", icon: ShoppingBag, price: "R$ 120" },
            ].map((service, idx) => (
              <Link key={idx} href="/services">
                <div className="text-center p-4 rounded-lg bg-card hover-elevate cursor-pointer" data-testid={`card-service-quick-${idx}`}>
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-2">
                    <service.icon className="w-5 h-5 text-primary" />
                  </div>
                  <p className="font-medium text-sm">{service.name}</p>
                  <p className="text-xs text-muted-foreground">{service.price}</p>
                </div>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
