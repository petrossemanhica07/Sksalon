import {
  users,
  services,
  serviceCategories,
  products,
  productCategories,
  appointments,
  queue,
  promotions,
  messages,
  notifications,
  staffSchedules,
  salonSettings,
  type User,
  type UpsertUser,
  type Service,
  type InsertService,
  type ServiceCategory,
  type InsertServiceCategory,
  type Product,
  type InsertProduct,
  type ProductCategory,
  type InsertProductCategory,
  type Appointment,
  type InsertAppointment,
  type Queue,
  type InsertQueue,
  type Promotion,
  type InsertPromotion,
  type Message,
  type InsertMessage,
  type Notification,
  type InsertNotification,
  type StaffSchedule,
  type InsertStaffSchedule,
  type SalonSetting,
  type InsertSalonSetting,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, gte, lte, or, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUsersByRole(role: string): Promise<User[]>;
  getAllUsers(): Promise<User[]>;

  // Service operations
  getAllServices(): Promise<Service[]>;
  getService(id: number): Promise<Service | undefined>;
  createService(service: InsertService): Promise<Service>;
  updateService(id: number, service: Partial<InsertService>): Promise<Service | undefined>;
  deleteService(id: number): Promise<void>;

  // Service categories
  getAllServiceCategories(): Promise<ServiceCategory[]>;
  createServiceCategory(category: InsertServiceCategory): Promise<ServiceCategory>;

  // Product operations
  getAllProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<void>;

  // Product categories
  getAllProductCategories(): Promise<ProductCategory[]>;
  createProductCategory(category: InsertProductCategory): Promise<ProductCategory>;

  // Appointment operations
  getAllAppointments(): Promise<Appointment[]>;
  getAppointmentsByClient(clientId: string): Promise<Appointment[]>;
  getAppointmentsByDate(date: Date): Promise<Appointment[]>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, appointment: Partial<InsertAppointment>): Promise<Appointment | undefined>;

  // Queue operations
  getQueue(): Promise<Queue[]>;
  getQueueByClient(clientId: string): Promise<Queue | undefined>;
  addToQueue(entry: InsertQueue): Promise<Queue>;
  updateQueueEntry(id: number, entry: Partial<InsertQueue>): Promise<Queue | undefined>;
  removeFromQueue(id: number): Promise<void>;

  // Promotion operations
  getAllPromotions(): Promise<Promotion[]>;
  getActivePromotions(): Promise<Promotion[]>;
  createPromotion(promotion: InsertPromotion): Promise<Promotion>;
  updatePromotion(id: number, promotion: Partial<InsertPromotion>): Promise<Promotion | undefined>;
  deletePromotion(id: number): Promise<void>;

  // Message operations
  getConversations(userId: string): Promise<User[]>;
  getMessages(userId1: string, userId2: string): Promise<Message[]>;
  sendMessage(message: InsertMessage): Promise<Message>;
  markMessageAsRead(id: number): Promise<void>;

  // Notification operations
  getNotifications(userId: string): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<void>;
  markAllNotificationsAsRead(userId: string): Promise<void>;
  deleteNotification(id: number): Promise<void>;

  // Staff schedule operations
  getStaffSchedules(staffId: string): Promise<StaffSchedule[]>;
  setStaffSchedule(schedule: InsertStaffSchedule): Promise<StaffSchedule>;

  // Salon settings
  getAllSettings(): Promise<SalonSetting[]>;
  getSetting(key: string): Promise<SalonSetting | undefined>;
  setSetting(key: string, value: string): Promise<SalonSetting>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, role));
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }

  // Service operations
  async getAllServices(): Promise<Service[]> {
    return await db.select().from(services);
  }

  async getService(id: number): Promise<Service | undefined> {
    const [service] = await db.select().from(services).where(eq(services.id, id));
    return service;
  }

  async createService(service: InsertService): Promise<Service> {
    const [newService] = await db.insert(services).values(service).returning();
    return newService;
  }

  async updateService(id: number, service: Partial<InsertService>): Promise<Service | undefined> {
    const [updated] = await db.update(services).set(service).where(eq(services.id, id)).returning();
    return updated;
  }

  async deleteService(id: number): Promise<void> {
    await db.delete(services).where(eq(services.id, id));
  }

  // Service categories
  async getAllServiceCategories(): Promise<ServiceCategory[]> {
    return await db.select().from(serviceCategories).orderBy(serviceCategories.order);
  }

  async createServiceCategory(category: InsertServiceCategory): Promise<ServiceCategory> {
    const [newCategory] = await db.insert(serviceCategories).values(category).returning();
    return newCategory;
  }

  // Product operations
  async getAllProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }

  async updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined> {
    const [updated] = await db.update(products).set(product).where(eq(products.id, id)).returning();
    return updated;
  }

  async deleteProduct(id: number): Promise<void> {
    await db.delete(products).where(eq(products.id, id));
  }

  // Product categories
  async getAllProductCategories(): Promise<ProductCategory[]> {
    return await db.select().from(productCategories);
  }

  async createProductCategory(category: InsertProductCategory): Promise<ProductCategory> {
    const [newCategory] = await db.insert(productCategories).values(category).returning();
    return newCategory;
  }

  // Appointment operations
  async getAllAppointments(): Promise<Appointment[]> {
    return await db.select().from(appointments).orderBy(desc(appointments.date));
  }

  async getAppointmentsByClient(clientId: string): Promise<Appointment[]> {
    return await db.select().from(appointments).where(eq(appointments.clientId, clientId)).orderBy(desc(appointments.date));
  }

  async getAppointmentsByDate(date: Date): Promise<Appointment[]> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);
    
    return await db.select().from(appointments)
      .where(and(gte(appointments.date, startOfDay), lte(appointments.date, endOfDay)))
      .orderBy(appointments.date);
  }

  async createAppointment(appointment: InsertAppointment): Promise<Appointment> {
    const [newAppointment] = await db.insert(appointments).values(appointment).returning();
    return newAppointment;
  }

  async updateAppointment(id: number, appointment: Partial<InsertAppointment>): Promise<Appointment | undefined> {
    const [updated] = await db.update(appointments).set(appointment).where(eq(appointments.id, id)).returning();
    return updated;
  }

  // Queue operations
  async getQueue(): Promise<Queue[]> {
    return await db.select().from(queue).orderBy(queue.position);
  }

  async getQueueByClient(clientId: string): Promise<Queue | undefined> {
    const [entry] = await db.select().from(queue)
      .where(and(eq(queue.clientId, clientId), or(eq(queue.status, "waiting"), eq(queue.status, "called"))))
      .orderBy(desc(queue.checkInTime));
    return entry;
  }

  async addToQueue(entry: InsertQueue): Promise<Queue> {
    const [lastEntry] = await db.select({ maxPosition: sql<number>`COALESCE(MAX(position), 0)` }).from(queue);
    const position = (lastEntry?.maxPosition || 0) + 1;
    
    const [newEntry] = await db.insert(queue).values({ ...entry, position }).returning();
    return newEntry;
  }

  async updateQueueEntry(id: number, entry: Partial<InsertQueue>): Promise<Queue | undefined> {
    const [updated] = await db.update(queue).set(entry).where(eq(queue.id, id)).returning();
    return updated;
  }

  async removeFromQueue(id: number): Promise<void> {
    await db.delete(queue).where(eq(queue.id, id));
  }

  // Promotion operations
  async getAllPromotions(): Promise<Promotion[]> {
    return await db.select().from(promotions).orderBy(desc(promotions.startDate));
  }

  async getActivePromotions(): Promise<Promotion[]> {
    const now = new Date();
    return await db.select().from(promotions)
      .where(and(
        eq(promotions.isActive, true),
        lte(promotions.startDate, now),
        gte(promotions.endDate, now)
      ));
  }

  async createPromotion(promotion: InsertPromotion): Promise<Promotion> {
    const [newPromotion] = await db.insert(promotions).values(promotion).returning();
    return newPromotion;
  }

  async updatePromotion(id: number, promotion: Partial<InsertPromotion>): Promise<Promotion | undefined> {
    const [updated] = await db.update(promotions).set(promotion).where(eq(promotions.id, id)).returning();
    return updated;
  }

  async deletePromotion(id: number): Promise<void> {
    await db.delete(promotions).where(eq(promotions.id, id));
  }

  // Message operations
  async getConversations(userId: string): Promise<User[]> {
    const sentTo = await db
      .selectDistinct({ id: messages.receiverId })
      .from(messages)
      .where(eq(messages.senderId, userId));
    
    const receivedFrom = await db
      .selectDistinct({ id: messages.senderId })
      .from(messages)
      .where(eq(messages.receiverId, userId));

    const userIds = [...new Set([...sentTo.map(m => m.id), ...receivedFrom.map(m => m.id)])].filter(Boolean) as string[];
    
    if (userIds.length === 0) {
      // Return admins for new conversations
      return await db.select().from(users).where(eq(users.role, "admin"));
    }
    
    return await db.select().from(users).where(sql`${users.id} = ANY(${userIds})`);
  }

  async getMessages(userId1: string, userId2: string): Promise<Message[]> {
    return await db.select().from(messages)
      .where(or(
        and(eq(messages.senderId, userId1), eq(messages.receiverId, userId2)),
        and(eq(messages.senderId, userId2), eq(messages.receiverId, userId1))
      ))
      .orderBy(messages.createdAt);
  }

  async sendMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(messages).values(message).returning();
    return newMessage;
  }

  async markMessageAsRead(id: number): Promise<void> {
    await db.update(messages).set({ isRead: true }).where(eq(messages.id, id));
  }

  // Notification operations
  async getNotifications(userId: string): Promise<Notification[]> {
    return await db.select().from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db.insert(notifications).values(notification).returning();
    return newNotification;
  }

  async markNotificationAsRead(id: number): Promise<void> {
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, id));
  }

  async markAllNotificationsAsRead(userId: string): Promise<void> {
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.userId, userId));
  }

  async deleteNotification(id: number): Promise<void> {
    await db.delete(notifications).where(eq(notifications.id, id));
  }

  // Staff schedule operations
  async getStaffSchedules(staffId: string): Promise<StaffSchedule[]> {
    return await db.select().from(staffSchedules).where(eq(staffSchedules.staffId, staffId));
  }

  async setStaffSchedule(schedule: InsertStaffSchedule): Promise<StaffSchedule> {
    const [newSchedule] = await db.insert(staffSchedules).values(schedule).returning();
    return newSchedule;
  }

  // Salon settings
  async getAllSettings(): Promise<SalonSetting[]> {
    return await db.select().from(salonSettings);
  }

  async getSetting(key: string): Promise<SalonSetting | undefined> {
    const [setting] = await db.select().from(salonSettings).where(eq(salonSettings.key, key));
    return setting;
  }

  async setSetting(key: string, value: string): Promise<SalonSetting> {
    const [setting] = await db
      .insert(salonSettings)
      .values({ key, value })
      .onConflictDoUpdate({
        target: salonSettings.key,
        set: { value },
      })
      .returning();
    return setting;
  }
}

export const storage = new DatabaseStorage();
